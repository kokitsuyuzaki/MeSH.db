### R code from vignette source 'MeSH.db.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: MeSH.db.Rnw:224-225
###################################################
library(MeSH.db)


###################################################
### code chunk number 2: MeSH.db.Rnw:232-233
###################################################
ls("package:MeSH.db")


###################################################
### code chunk number 3: MeSH.db.Rnw:241-242
###################################################
cols(MeSHMAPCOUNTS)


###################################################
### code chunk number 4: MeSH.db.Rnw:249-250
###################################################
keytypes(MeSHMAPCOUNTS)


###################################################
### code chunk number 5: MeSH.db.Rnw:258-260
###################################################
k <- keys(MeSHMAPCOUNTS, keytype="MAPNAME")
head(k)


###################################################
### code chunk number 6: MeSH.db.Rnw:267-269
###################################################
select(MeSHMAPCOUNTS, keys=k[1,], cols=c("MAPNAME","COUNT"),
       keytype="MAPNAME")


###################################################
### code chunk number 7: MeSH.db.Rnw:276-277
###################################################
select(MeSHMAPCOUNTS, keys=k[1,], cols=c("MAPNAME","COUNT"))


###################################################
### code chunk number 8: MeSH.db.Rnw:289-290
###################################################
cols(MeSHTERM)


###################################################
### code chunk number 9: MeSH.db.Rnw:297-298
###################################################
keytypes(MeSHTERM)


###################################################
### code chunk number 10: MeSH.db.Rnw:306-309
###################################################
LEU <- select(MeSHTERM, keys="Leukemia",
            cols=c("MESHID", "MESHTERM", "MESHCATEGORY"), keytype="MESHTERM")
LEU


###################################################
### code chunk number 11: MeSH.db.Rnw:319-321 (eval = FALSE)
###################################################
## select(MeSHSYNONYM, keys=LEU[1,1],
##        cols=c("MESHID","MESHSYNONYM"), keytype="MESHTERM")


###################################################
### code chunk number 12: MeSH.db.Rnw:325-326
###################################################
writeLines(strwrap(capture.output(select(MeSHSYNONYM, keys=LEU[1,1], cols=c("MESHID","MESHSYNONYM")))))


###################################################
### code chunk number 13: MeSH.db.Rnw:334-336
###################################################
select(MeSHQUALIFIER, keys=LEU[1,1], 
       cols=c("QUALIFIERID","SUBHEADING","MESHID"), keytype="MESHID")


###################################################
### code chunk number 14: MeSH.db.Rnw:342-345
###################################################
ANC <- select(MeSHCAOR, keys=LEU[1,1], 
       cols=c("ANCESTORMESHID","OFFSPRINGMESHID"), keytype="OFFSPRINGMESHID")
ANC


###################################################
### code chunk number 15: MeSH.db.Rnw:352-353
###################################################
select(MeSHTERM, keys=ANC[,1], cols=c("MESHTERM"), keytype="MESHID")


###################################################
### code chunk number 16: MeSH.db.Rnw:359-362
###################################################
OFF <- select(MeSHCAOR, keys=LEU[1,1], 
       cols=c("ANCESTORMESHID","OFFSPRINGMESHID"), keytype="ANCESTORMESHID")
OFF


###################################################
### code chunk number 17: MeSH.db.Rnw:369-372
###################################################
CHI <- select(MeSHCPCR, keys=LEU[1,1], 
       cols=c("PARENTMESHID","CHILDMESHID"), keytype="PARENTMESHID")
CHI


###################################################
### code chunk number 18: MeSH.db.Rnw:378-379
###################################################
select(MeSHTERM, keys=CHI[,2], cols=c("MESHTERM"), keytype="MESHID")


###################################################
### code chunk number 19: session
###################################################
sessionInfo()


