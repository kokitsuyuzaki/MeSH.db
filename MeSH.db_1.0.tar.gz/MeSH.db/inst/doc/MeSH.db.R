### R code from vignette source 'MeSH.db.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: MeSH.db.Rnw:218-219
###################################################
library(MeSH.db)


###################################################
### code chunk number 2: MeSH.db.Rnw:226-227
###################################################
ls("package:MeSH.db")


###################################################
### code chunk number 3: MeSH.db.Rnw:235-236
###################################################
columns(MeSHMAPCOUNTS)


###################################################
### code chunk number 4: MeSH.db.Rnw:243-244
###################################################
keytypes(MeSHMAPCOUNTS)


###################################################
### code chunk number 5: MeSH.db.Rnw:252-254
###################################################
k <- keys(MeSHMAPCOUNTS, keytype="MAPNAME")
head(k)


###################################################
### code chunk number 6: MeSH.db.Rnw:261-263
###################################################
select(MeSHMAPCOUNTS, keys=k[1,], columns=c("MAPNAME","COUNT"),
       keytype="MAPNAME")


###################################################
### code chunk number 7: MeSH.db.Rnw:270-271
###################################################
select(MeSHMAPCOUNTS, keys=k[1,], columns=c("MAPNAME","COUNT"))


###################################################
### code chunk number 8: MeSH.db.Rnw:283-284
###################################################
columns(MeSHTERM)


###################################################
### code chunk number 9: MeSH.db.Rnw:291-292
###################################################
keytypes(MeSHTERM)


###################################################
### code chunk number 10: MeSH.db.Rnw:300-303
###################################################
LEU <- select(MeSHTERM, keys="Leukemia",
            columns=c("MESHID", "MESHTERM", "MESHCATEGORY"), keytype="MESHTERM")
LEU


###################################################
### code chunk number 11: MeSH.db.Rnw:313-315 (eval = FALSE)
###################################################
## select(MeSHSYNONYM, keys=LEU[1,1],
##        columns=c("MESHID","MESHSYNONYM"), keytype="MESHTERM")


###################################################
### code chunk number 12: MeSH.db.Rnw:319-320
###################################################
writeLines(strwrap(capture.output(select(MeSHSYNONYM, keys=LEU[1,1], columns=c("MESHID","MESHSYNONYM")))))


###################################################
### code chunk number 13: MeSH.db.Rnw:328-330
###################################################
select(MeSHQUALIFIER, keys=LEU[1,1], 
       columns=c("QUALIFIERID","SUBHEADING","MESHID"), keytype="MESHID")


###################################################
### code chunk number 14: MeSH.db.Rnw:336-339
###################################################
ANC <- select(MeSHCAOR, keys=LEU[1,1], 
       columns=c("ANCESTORMESHID","OFFSPRINGMESHID"), keytype="OFFSPRINGMESHID")
ANC


###################################################
### code chunk number 15: MeSH.db.Rnw:346-347
###################################################
select(MeSHTERM, keys=ANC[,1], columns=c("MESHTERM"), keytype="MESHID")


###################################################
### code chunk number 16: MeSH.db.Rnw:353-356
###################################################
OFF <- select(MeSHCAOR, keys=LEU[1,1], 
       columns=c("ANCESTORMESHID","OFFSPRINGMESHID"), keytype="ANCESTORMESHID")
OFF


###################################################
### code chunk number 17: MeSH.db.Rnw:363-366
###################################################
CHI <- select(MeSHCPCR, keys=LEU[1,1], 
       columns=c("PARENTMESHID","CHILDMESHID"), keytype="PARENTMESHID")
CHI


###################################################
### code chunk number 18: MeSH.db.Rnw:372-373
###################################################
select(MeSHTERM, keys=CHI[,2], columns=c("MESHTERM"), keytype="MESHID")


###################################################
### code chunk number 19: session
###################################################
sessionInfo()


