### R code from vignette source 'MeSH.db.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: MeSH.db.Rnw:227-228
###################################################
library(MeSH.db)


###################################################
### code chunk number 2: MeSH.db.Rnw:235-236
###################################################
ls("package:MeSH.db")


###################################################
### code chunk number 3: MeSH.db.Rnw:244-245
###################################################
columns(MeSHMAPCOUNTS)


###################################################
### code chunk number 4: MeSH.db.Rnw:252-253
###################################################
keytypes(MeSHMAPCOUNTS)


###################################################
### code chunk number 5: MeSH.db.Rnw:261-263
###################################################
k <- keys(MeSHMAPCOUNTS, keytype="MAPNAME")
head(k)


###################################################
### code chunk number 6: MeSH.db.Rnw:270-272
###################################################
select(MeSHMAPCOUNTS, keys=k[1,], columns=c("MAPNAME","COUNT"),
       keytype="MAPNAME")


###################################################
### code chunk number 7: MeSH.db.Rnw:279-280
###################################################
select(MeSHMAPCOUNTS, keys=k[1,], columns=c("MAPNAME","COUNT"))


###################################################
### code chunk number 8: MeSH.db.Rnw:292-293
###################################################
columns(MeSHTERM)


###################################################
### code chunk number 9: MeSH.db.Rnw:300-301
###################################################
keytypes(MeSHTERM)


###################################################
### code chunk number 10: MeSH.db.Rnw:309-312
###################################################
LEU <- select(MeSHTERM, keys="Leukemia",
            columns=c("MESHID", "MESHTERM", "MESHCATEGORY"), keytype="MESHTERM")
LEU


###################################################
### code chunk number 11: MeSH.db.Rnw:322-324 (eval = FALSE)
###################################################
## select(MeSHSYNONYM, keys=LEU[1,1],
##        columns=c("MESHID","MESHSYNONYM"), keytype="MESHTERM")


###################################################
### code chunk number 12: MeSH.db.Rnw:328-329
###################################################
writeLines(strwrap(capture.output(select(MeSHSYNONYM, keys=LEU[1,1], columns=c("MESHID","MESHSYNONYM")))))


###################################################
### code chunk number 13: MeSH.db.Rnw:337-339
###################################################
select(MeSHQUALIFIER, keys=LEU[1,1], 
       columns=c("QUALIFIERID","SUBHEADING","MESHID"), keytype="MESHID")


###################################################
### code chunk number 14: MeSH.db.Rnw:345-348
###################################################
ANC <- select(MeSHCAOR, keys=LEU[1,1], 
       columns=c("ANCESTORMESHID","OFFSPRINGMESHID"), keytype="OFFSPRINGMESHID")
ANC


###################################################
### code chunk number 15: MeSH.db.Rnw:355-356
###################################################
select(MeSHTERM, keys=ANC[,1], columns=c("MESHTERM"), keytype="MESHID")


###################################################
### code chunk number 16: MeSH.db.Rnw:362-365
###################################################
OFF <- select(MeSHCAOR, keys=LEU[1,1], 
       columns=c("ANCESTORMESHID","OFFSPRINGMESHID"), keytype="ANCESTORMESHID")
OFF


###################################################
### code chunk number 17: MeSH.db.Rnw:372-375
###################################################
CHI <- select(MeSHCPCR, keys=LEU[1,1], 
       columns=c("PARENTMESHID","CHILDMESHID"), keytype="PARENTMESHID")
CHI


###################################################
### code chunk number 18: MeSH.db.Rnw:381-382
###################################################
select(MeSHTERM, keys=CHI[,2], columns=c("MESHTERM"), keytype="MESHID")


###################################################
### code chunk number 19: session
###################################################
sessionInfo()


