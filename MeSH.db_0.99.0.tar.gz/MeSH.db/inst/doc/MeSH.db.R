### R code from vignette source 'MeSH.db.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: MeSH.db.Rnw:228-229
###################################################
library(MeSH.db)


###################################################
### code chunk number 2: MeSH.db.Rnw:236-237
###################################################
ls("package:MeSH.db")


###################################################
### code chunk number 3: MeSH.db.Rnw:245-246
###################################################
columns(MeSHMAPCOUNTS)


###################################################
### code chunk number 4: MeSH.db.Rnw:253-254
###################################################
keytypes(MeSHMAPCOUNTS)


###################################################
### code chunk number 5: MeSH.db.Rnw:262-264
###################################################
k <- keys(MeSHMAPCOUNTS, keytype="MAPNAME")
head(k)


###################################################
### code chunk number 6: MeSH.db.Rnw:271-273
###################################################
select(MeSHMAPCOUNTS, keys=k[1,], columns=c("MAPNAME","COUNT"),
       keytype="MAPNAME")


###################################################
### code chunk number 7: MeSH.db.Rnw:280-281
###################################################
select(MeSHMAPCOUNTS, keys=k[1,], columns=c("MAPNAME","COUNT"))


###################################################
### code chunk number 8: MeSH.db.Rnw:293-294
###################################################
columns(MeSHTERM)


###################################################
### code chunk number 9: MeSH.db.Rnw:301-302
###################################################
keytypes(MeSHTERM)


###################################################
### code chunk number 10: MeSH.db.Rnw:310-313
###################################################
LEU <- select(MeSHTERM, keys="Leukemia",
            columns=c("MESHID", "MESHTERM", "MESHCATEGORY"), keytype="MESHTERM")
LEU


###################################################
### code chunk number 11: MeSH.db.Rnw:323-325 (eval = FALSE)
###################################################
## select(MeSHSYNONYM, keys=LEU[1,1],
##        columns=c("MESHID","MESHSYNONYM"), keytype="MESHTERM")


###################################################
### code chunk number 12: MeSH.db.Rnw:329-330
###################################################
writeLines(strwrap(capture.output(select(MeSHSYNONYM, keys=LEU[1,1], columns=c("MESHID","MESHSYNONYM")))))


###################################################
### code chunk number 13: MeSH.db.Rnw:338-340
###################################################
select(MeSHQUALIFIER, keys=LEU[1,1], 
       columns=c("QUALIFIERID","SUBHEADING","MESHID"), keytype="MESHID")


###################################################
### code chunk number 14: MeSH.db.Rnw:346-349
###################################################
ANC <- select(MeSHCAOR, keys=LEU[1,1], 
       columns=c("ANCESTORMESHID","OFFSPRINGMESHID"), keytype="OFFSPRINGMESHID")
ANC


###################################################
### code chunk number 15: MeSH.db.Rnw:356-357
###################################################
select(MeSHTERM, keys=ANC[,1], columns=c("MESHTERM"), keytype="MESHID")


###################################################
### code chunk number 16: MeSH.db.Rnw:363-366
###################################################
OFF <- select(MeSHCAOR, keys=LEU[1,1], 
       columns=c("ANCESTORMESHID","OFFSPRINGMESHID"), keytype="ANCESTORMESHID")
OFF


###################################################
### code chunk number 17: MeSH.db.Rnw:373-376
###################################################
CHI <- select(MeSHCPCR, keys=LEU[1,1], 
       columns=c("PARENTMESHID","CHILDMESHID"), keytype="PARENTMESHID")
CHI


###################################################
### code chunk number 18: MeSH.db.Rnw:382-383
###################################################
select(MeSHTERM, keys=CHI[,2], columns=c("MESHTERM"), keytype="MESHID")


###################################################
### code chunk number 19: session
###################################################
sessionInfo()


